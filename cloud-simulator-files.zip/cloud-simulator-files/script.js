const requests = [];

    const $ = (id) => document.getElementById(id);

    const priorityLabel = (p) => ({ 1: 'High', 2: 'Medium', 3: 'Low' }[p] || 'Medium');
    const clientBadgeClass = (t) => ({ premium: 'premium', free: 'free', urgent: 'urgent' }[t] || 'free');
    const priorityBadgeClass = (p) => ({ 1: 'high', 2: 'medium', 3: 'low' }[p] || 'medium');

    function renderQueue() {
      $('mTotal').textContent = requests.length;
      const q = $('queueList');
      if (!requests.length) {
        q.innerHTML = '<div class="muted-cell">No requests added yet.</div>';
        return;
      }
      q.innerHTML = requests
        .map((r) => `
          <div class="request-item">
            <div>
              <div class="name">${escapeHtml(r.id)}</div>
              <div class="small">${escapeHtml(r.note || 'Cloud API request')}</div>
            </div>
            <div><span class="badge ${clientBadgeClass(r.clientType)}">${r.clientType.toUpperCase()}</span></div>
            <div><span class="badge ${priorityBadgeClass(r.priority)}">${priorityLabel(r.priority)}</span></div>
            <div class="small">Arrival: ${r.arrival}</div>
            <div class="small">Service: ${r.service}</div>
          </div>
        `)
        .join('');
    }

    function addRequest(req) {
      if (!req.id || !String(req.id).trim()) return alert('Request ID is required.');
      if (!Number.isFinite(req.arrival) || req.arrival < 0) return alert('Arrival time must be 0 or more.');
      if (!Number.isFinite(req.service) || req.service <= 0) return alert('Service time must be greater than 0.');
      requests.push(req);
      renderQueue();
    }

    function addFromForm() {
      const req = {
        id: $('reqId').value.trim(),
        arrival: Number($('arrival').value),
        service: Number($('service').value),
        priority: Number($('priority').value),
        clientType: $('clientType').value,
        note: buildNote($('clientType').value, $('priority').value)
      };
      addRequest(req);
      $('reqId').value = '';
    }

    function buildNote(clientType, priority) {
      if (clientType === 'urgent' || Number(priority) === 1) return 'SLA-sensitive API request';
      if (clientType === 'premium') return 'Premium user request';
      return 'Free-tier request';
    }

    function sampleData() {
      const samples = [
        { id: 'REQ-101', arrival: 0, service: 6, priority: 2, clientType: 'premium', note: 'Login + dashboard load' },
        { id: 'REQ-102', arrival: 1, service: 3, priority: 3, clientType: 'free', note: 'Search request' },
        { id: 'REQ-103', arrival: 2, service: 5, priority: 1, clientType: 'urgent', note: 'Payment verification' },
        { id: 'REQ-104', arrival: 3, service: 4, priority: 2, clientType: 'premium', note: 'Upload metadata' },
        { id: 'REQ-105', arrival: 4, service: 2, priority: 3, clientType: 'free', note: 'Profile read request' },
        { id: 'REQ-106', arrival: 5, service: 7, priority: 1, clientType: 'urgent', note: 'Critical alert processing' }
      ];
      samples.forEach(addRequest);
    }

    function clearAll() {
      requests.length = 0;
      $('reportBody').innerHTML = '<tr><td colspan="10" class="muted-cell">No simulation run yet.</td></tr>';
      $('timeline').innerHTML = '';
      renderQueue();
      updateMetrics({ totalTime: 0, busyTime: 0, completed: 0, waiting: 0, turnaround: 0, response: 0 });
    }

    function scheduleFCFS(items) {
      const sorted = [...items].sort((a, b) => a.arrival - b.arrival || a.id.localeCompare(b.id));
      let time = 0;
      const result = [];
      for (const r of sorted) {
        const start = Math.max(time, r.arrival);
        const finish = start + r.service;
        result.push({ ...r, start, finish, waiting: start - r.arrival, turnaround: finish - r.arrival, response: start - r.arrival, slice: r.service });
        time = finish;
      }
      return result;
    }

    function schedulePriority(items) {
      const pending = items.map((r) => ({ ...r }));
      const result = [];
      let time = 0;
      let completed = 0;
      const total = pending.length;

      while (completed < total) {
        const ready = pending.filter((r) => !r._done && r.arrival <= time);
        if (!ready.length) {
          time = Math.min(...pending.filter((r) => !r._done).map((r) => r.arrival));
          continue;
        }

        ready.sort((a, b) => a.priority - b.priority || a.arrival - b.arrival || a.service - b.service || a.id.localeCompare(b.id));
        const r = ready[0];
        const start = Math.max(time, r.arrival);
        const finish = start + r.service;
        r._done = true;
        result.push({ ...r, start, finish, waiting: start - r.arrival, turnaround: finish - r.arrival, response: start - r.arrival, slice: r.service });
        time = finish;
        completed++;
      }

      return result.sort((a, b) => a.start - b.start || a.arrival - b.arrival);
    }

    function scheduleRoundRobin(items, quantum) {
      const q = Math.max(1, Number(quantum) || 1);
      const byArrival = [...items].sort((a, b) => a.arrival - b.arrival || a.id.localeCompare(b.id));
      const remain = new Map(byArrival.map((r) => [r.id, r.service]));
      const firstStart = new Map();
      const finish = new Map();
      const execution = [];
      const queue = [];
      let time = 0;
      let i = 0;

      while (i < byArrival.length || queue.length) {
        while (i < byArrival.length && byArrival[i].arrival <= time) {
          queue.push(byArrival[i]);
          i++;
        }

        if (!queue.length) {
          time = byArrival[i].arrival;
          continue;
        }

        const r = queue.shift();
        if (!firstStart.has(r.id)) firstStart.set(r.id, time);
        const run = Math.min(q, remain.get(r.id));
        execution.push({ ...r, start: time, finish: time + run, slice: run });
        time += run;
        remain.set(r.id, remain.get(r.id) - run);

        while (i < byArrival.length && byArrival[i].arrival <= time) {
          queue.push(byArrival[i]);
          i++;
        }

        if (remain.get(r.id) > 0) {
          queue.push(r);
        } else {
          finish.set(r.id, time);
        }
      }

      const summary = byArrival.map((r) => {
        const fin = finish.get(r.id);
        const first = firstStart.get(r.id);
        return {
          ...r,
          start: first,
          finish: fin,
          waiting: fin - r.arrival - r.service,
          turnaround: fin - r.arrival,
          response: first - r.arrival,
          slice: r.service
        };
      });

      summary.sort((a, b) => a.start - b.start || a.arrival - b.arrival);
      summary._timeline = execution;
      return summary;
    }

    function simulate() {
      if (!requests.length) {
        alert('Please add at least one request.');
        return;
      }

      const algo = $('algo').value;
      const quantum = Number($('quantum').value) || 2;
      let result = [];
      let timeline = [];

      if (algo === 'fcfs') {
        result = scheduleFCFS(requests);
        timeline = result.map((r) => ({ ...r, slice: r.service }));
      } else if (algo === 'priority') {
        result = schedulePriority(requests);
        timeline = result.map((r) => ({ ...r, slice: r.service }));
      } else {
        result = scheduleRoundRobin(requests, quantum);
        timeline = result._timeline || result.map((r) => ({ ...r, slice: r.service }));
      }

      renderReport(result);
      renderTimeline(timeline, algo, quantum);
      updateMetrics(calcMetrics(result, timeline));
    }

    function renderReport(result) {
      const body = $('reportBody');
      body.innerHTML = result.map((r) => `
        <tr class="${r.priority === 1 ? 'highlight-row' : ''}">
          <td><strong>${escapeHtml(r.id)}</strong></td>
          <td><span class="badge ${clientBadgeClass(r.clientType)}">${r.clientType.toUpperCase()}</span></td>
          <td><span class="badge ${priorityBadgeClass(r.priority)}">${priorityLabel(r.priority)}</span></td>
          <td>${r.arrival}</td>
          <td>${r.service}</td>
          <td>${r.start}</td>
          <td>${r.finish}</td>
          <td>${r.waiting}</td>
          <td>${r.turnaround}</td>
          <td>${r.response}</td>
        </tr>
      `).join('');
      $('mDone').textContent = result.length;
    }

    function renderTimeline(timeline, algo, quantum) {
      const el = $('timeline');
      if (!timeline.length) {
        el.innerHTML = '<div class="muted-cell">No timeline available.</div>';
        return;
      }

      el.innerHTML = timeline.map((r, idx) => `
        <div class="slot" title="${escapeHtml(r.id)}">
          <div class="time">${r.start} → ${r.finish}</div>
          <div class="name">${escapeHtml(r.id)}</div>
          <div class="detail">Slice: ${r.slice} time unit(s)<br>Arrived: ${r.arrival}<br>Mode: ${algo.toUpperCase()}${algo === 'rr' ? ` (q=${quantum})` : ''}</div>
        </div>
      `).join('');
    }

    function calcMetrics(result, timeline) {
      if (!result.length) return { totalTime: 0, busyTime: 0, completed: 0, waiting: 0, turnaround: 0, response: 0 };
      const totalTime = Math.max(...result.map((r) => r.finish));
      const busyTime = result.reduce((sum, r) => sum + r.service, 0);
      const completed = result.length;
      const waiting = avg(result.map((r) => r.waiting));
      const turnaround = avg(result.map((r) => r.turnaround));
      const response = avg(result.map((r) => r.response));
      return { totalTime, busyTime, completed, waiting, turnaround, response };
    }

    function updateMetrics(m) {
      $('mWaiting').textContent = m.waiting.toFixed(2);
      $('mTurnaround').textContent = m.turnaround.toFixed(2);
      $('mResponse').textContent = m.response.toFixed(2);
      $('mLatency').textContent = m.turnaround.toFixed(2);
      $('mThroughput').textContent = m.totalTime > 0 ? (m.completed / m.totalTime).toFixed(2) : '0.00';
      $('mUtil').textContent = m.totalTime > 0 ? ((m.busyTime / m.totalTime) * 100).toFixed(2) + '%' : '0.00%';
    }

    function avg(arr) {
      if (!arr.length) return 0;
      return arr.reduce((a, b) => a + b, 0) / arr.length;
    }

    function escapeHtml(str) {
      return String(str)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
    }

    $('addBtn').addEventListener('click', addFromForm);
    $('runBtn').addEventListener('click', simulate);
    $('clearBtn').addEventListener('click', clearAll);
    $('addSampleBtn').addEventListener('click', sampleData);

    renderQueue();
    updateMetrics({ totalTime: 0, busyTime: 0, completed: 0, waiting: 0, turnaround: 0, response: 0 });